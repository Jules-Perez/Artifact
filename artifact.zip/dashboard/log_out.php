<?php
	
	header("location: ../");

?>