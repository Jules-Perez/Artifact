	<link href="https://fonts.googleapis.com/css?family=Cabin|Courgette|Ubuntu+Condensed&display=swap" rel="stylesheet">

	<link rel="stylesheet" type="text/css" href="../../../style.css">
	<link rel="stylesheet" type="text/css" href="../../../fontawesome/css/all.css">
	<link rel="stylesheet" type="text/css" href="../../dashboardstyle.css">
	
	
	<script type="text/javascript" src="../../../jquery.js"></script>

  	<script type="text/javascript" src="../../dashboardscript.js"></script>
  	

